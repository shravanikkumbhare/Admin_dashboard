package com.example.demo.controller;
import com.example.demo.model.Consultant;
import com.example.demo.services.ConsultantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consultants")
public class ConsultantController {

    @Autowired
    private ConsultantService consultantService;

    @PostMapping
    public ResponseEntity<Consultant> addConsultant(@RequestBody Consultant consultant) {
        Consultant savedConsultant = consultantService.addConsultant(consultant);
        return new ResponseEntity<>(savedConsultant, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Consultant>> getAllConsultants() {
        List<Consultant> consultants = consultantService.getAllConsultants();
        return new ResponseEntity<>(consultants, HttpStatus.OK);
    }

    @GetMapping("/{consultantId}")
    public ResponseEntity<Consultant> getConsultantById(@PathVariable Long consultantId) {
        Consultant consultant = consultantService.getConsultantById(consultantId);
        return new ResponseEntity<>(consultant, HttpStatus.OK);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Consultant>> searchConsultants(@RequestParam(required = false) String name,
                                                              @RequestParam(required = false) String jobRole) {
        List<Consultant> consultants = consultantService.searchConsultants(name, jobRole);
        return new ResponseEntity<>(consultants, HttpStatus.OK);
    }
}
