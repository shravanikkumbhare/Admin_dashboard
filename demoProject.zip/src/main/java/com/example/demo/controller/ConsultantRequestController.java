package com.example.demo.controller;
import com.example.demo.model.ConsultantRequest;
import com.example.demo.services.ConsultantRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consultant-requests")
public class ConsultantRequestController {

    @Autowired
    private ConsultantRequestService consultantRequestService;

    @GetMapping
    public ResponseEntity<List<ConsultantRequest>> getAllConsultantRequests() {
        List<ConsultantRequest> consultantRequests = consultantRequestService.getAllConsultantRequests();
        return new ResponseEntity<>(consultantRequests, HttpStatus.OK);
    }

    @PutMapping("/{requestId}/approve")
    public ResponseEntity<String> approveConsultantRequest(@PathVariable Long requestId) {
        consultantRequestService.approveConsultantRequest(requestId);
        return new ResponseEntity<>("Consultant request approved successfully", HttpStatus.OK);
    }

    @PutMapping("/{requestId}/reject")
    public ResponseEntity<String> rejectConsultantRequest(@PathVariable Long requestId) {
        consultantRequestService.rejectConsultantRequest(requestId);
        return new ResponseEntity<>("Consultant request rejected successfully", HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<ConsultantRequest> addConsultantRequest(@RequestBody ConsultantRequest consultantRequest) {
        ConsultantRequest savedRequest = consultantRequestService.addConsultantRequest(consultantRequest);
        return new ResponseEntity<>(savedRequest, HttpStatus.CREATED);
    }
}
