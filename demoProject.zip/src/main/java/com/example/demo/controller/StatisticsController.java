package com.example.demo.controller;
import com.example.demo.services.StatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/statistics")
public class StatisticsController {

    @Autowired
    private StatisticsService statisticsService;

    @GetMapping("/consultants")
    public ResponseEntity<Long> getTotalConsultants() {
        Long totalConsultants = statisticsService.getTotalConsultants();
        return new ResponseEntity<>(totalConsultants, HttpStatus.OK);
    }

    @GetMapping("/clients")
    public ResponseEntity<Long> getTotalClients() {
        Long totalClients = statisticsService.getTotalClients();
        return new ResponseEntity<>(totalClients, HttpStatus.OK);
    }

    @GetMapping("/sessions")
    public ResponseEntity<Long> getTotalSessions() {
        Long totalSessions = statisticsService.getTotalSessions();
        return new ResponseEntity<>(totalSessions, HttpStatus.OK);
    }
}
