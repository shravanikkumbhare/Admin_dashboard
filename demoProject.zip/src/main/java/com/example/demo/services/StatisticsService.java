package com.example.demo.services;
import com.example.demo.repository.ClientRepository;
import com.example.demo.repository.ConsultantRepository;
import com.example.demo.repository.SessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StatisticsService {

    @Autowired
    private ConsultantRepository consultantRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private SessionRepository sessionRepository;

    public Long getTotalConsultants() {
        return consultantRepository.count();
    }

    public Long getTotalClients() {
        return clientRepository.count();
    }

    public Long getTotalSessions() {
        return sessionRepository.count();
    }
}
