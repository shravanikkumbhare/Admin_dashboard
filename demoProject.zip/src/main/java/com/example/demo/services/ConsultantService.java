package com.example.demo.services;
import com.example.demo.model.Consultant;
import com.example.demo.repository.ConsultantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
public class ConsultantService {

    @Autowired
    private ConsultantRepository consultantRepository;

    public Consultant addConsultant(Consultant consultant) {
        return consultantRepository.save(consultant);
    }

    public List<Consultant> getAllConsultants() {
        return consultantRepository.findAll();
    }

    public Consultant getConsultantById(Long consultantId) {
        return consultantRepository.findById(consultantId)
                .orElseThrow(() -> new EntityNotFoundException("Consultant not found with id: " + consultantId));
    }

    public List<Consultant> searchConsultants(String name, String jobRole) {
        if (name != null && jobRole != null) {
            return consultantRepository.findByNameAndJobRole(name, jobRole);
        } else if (name != null) {
            return consultantRepository.findByName(name);
        } else if (jobRole != null) {
            return consultantRepository.findByJobRole(jobRole);
        } else {
            return consultantRepository.findAll();
        }
    }
}
