package com.example.demo.services;
import com.example.demo.model.ConsultantRequest;
import com.example.demo.model.RequestStatus;
import com.example.demo.repository.ConsultantRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
public class ConsultantRequestService {

    @Autowired
    private ConsultantRequestRepository consultantRequestRepository;

    public List<ConsultantRequest> getAllConsultantRequests() {
        return consultantRequestRepository.findAll();
    }

    public void approveConsultantRequest(Long requestId) {
        ConsultantRequest request = getConsultantRequestById(requestId);
        request.setStatus(RequestStatus.APPROVED);
        consultantRequestRepository.save(request);
    }

    public void rejectConsultantRequest(Long requestId) {
        ConsultantRequest request = getConsultantRequestById(requestId);
        request.setStatus(RequestStatus.REJECTED);
        consultantRequestRepository.save(request);
    }

    public ConsultantRequest addConsultantRequest(ConsultantRequest consultantRequest) {
        consultantRequest.setStatus(RequestStatus.PENDING);
        return consultantRequestRepository.save(consultantRequest);
    }

    private ConsultantRequest getConsultantRequestById(Long requestId) {
        return consultantRequestRepository.findById(requestId)
                .orElseThrow(() -> new EntityNotFoundException("Consultant request not found with id: " + requestId));
    }
}
