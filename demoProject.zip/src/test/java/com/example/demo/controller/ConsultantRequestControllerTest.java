package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;

import com.example.demo.model.ConsultantRequest;
import com.example.demo.services.ConsultantRequestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class ConsultantRequestControllerTest {

    @InjectMocks
    private ConsultantRequestController consultantRequestController;

    @Mock
    private ConsultantRequestService consultantRequestService;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(consultantRequestController).build();
    }

    @Test
    public void testGetAllConsultantRequests() throws Exception {
        ConsultantRequest request1 = new ConsultantRequest();
        request1.setId(1L);
        request1.setName("John Doe");

        ConsultantRequest request2 = new ConsultantRequest();
        request2.setId(2L);
        request2.setName("Jane Smith");

        List<ConsultantRequest> requests = Arrays.asList(request1, request2);

        when(consultantRequestService.getAllConsultantRequests()).thenReturn(requests);

        mockMvc.perform(get("/api/consultant-requests"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].name").value("John Doe"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].name").value("Jane Smith"));

        verify(consultantRequestService, times(1)).getAllConsultantRequests();
        verifyNoMoreInteractions(consultantRequestService);
    }

    // Add more test methods for other controller endpoints
}
