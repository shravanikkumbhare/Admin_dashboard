package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;

import com.example.demo.services.StatisticsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Arrays;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class StatisticsControllerTest {

    @InjectMocks
    private StatisticsController statisticsController;

    @Mock
    private StatisticsService statisticsService;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(statisticsController).build();
    }

    @Test
    public void testGetTotalConsultants() throws Exception {
        when(statisticsService.getTotalConsultants()).thenReturn(10L);

        mockMvc.perform(get("/api/statistics/consultants"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").value(10));

        verify(statisticsService, times(1)).getTotalConsultants();
        verifyNoMoreInteractions(statisticsService);
    }

    @Test
    public void testGetTotalClients() throws Exception {
        when(statisticsService.getTotalClients()).thenReturn(20L);

        mockMvc.perform(get("/api/statistics/clients"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").value(20));

        verify(statisticsService, times(1)).getTotalClients();
        verifyNoMoreInteractions(statisticsService);
    }

    @Test
    public void testGetTotalSessions() throws Exception {
        when(statisticsService.getTotalSessions()).thenReturn(30L);

        mockMvc.perform(get("/api/statistics/sessions"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").value(30));

        verify(statisticsService, times(1)).getTotalSessions();
        verifyNoMoreInteractions(statisticsService);
    }
}
