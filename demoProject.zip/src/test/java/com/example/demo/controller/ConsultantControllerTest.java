package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;

import com.example.demo.model.Consultant;
import com.example.demo.services.ConsultantService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class ConsultantControllerTest {

    @InjectMocks
    private ConsultantController consultantController;

    @Mock
    private ConsultantService consultantService;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this); // Initialize mocks
        this.mockMvc = MockMvcBuilders.standaloneSetup(consultantController).build();
    }

    @Test
    public void testGetAllConsultants() throws Exception {
        // Mock data
        Consultant consultant1 = new Consultant();
        consultant1.setId(1L);
        consultant1.setName("John Doe");

        Consultant consultant2 = new Consultant();
        consultant2.setId(2L);
        consultant2.setName("Jane Smith");

        List<Consultant> consultants = Arrays.asList(consultant1, consultant2);

        // Set up behavior of the service mock
        when(consultantService.getAllConsultants()).thenReturn(consultants);

        // Perform request and verify response
        mockMvc.perform(get("/api/consultants"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].name").value("John Doe"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].name").value("Jane Smith"));

        // Verify that the service method was called
        verify(consultantService, times(1)).getAllConsultants();
        verifyNoMoreInteractions(consultantService);
    }

    // Add more test methods for other controller endpoints
}